# Drive + LIFF Video Library (Template)

เทมเพลตนี้ทำไว้เพื่อ:
- เปิด “คลังคลิป” ใน LINE ด้วย LIFF (เหมือนมีแอปย่อย)
- วิดีโอเก็บไว้ใน Google Drive (ไม่ใช้ YouTube)
- มีฟีเจอร์: ค้นหา / ดูต่อ / ดูแล้ว / แชร์ / โทร / แชท

## สิ่งที่ต้องทำ (สั้นมาก)

1) เอา Google Drive FILE ID ของแต่ละคลิปมาใส่ใน `docs/data.json` (ช่อง `driveId`)
2) ใส่เบอร์โทรพยาบาล และ LINE OA ID ใน `docs/data.json` (contacts)
3) ตั้งค่า GitHub Pages ให้ publish จาก `/docs`
4) สร้าง LIFF app และเอา LIFF ID มาใส่ใน `docs/index.html`
5) เอา LIFF URL ไปผูกกับ Rich Menu (A/B/C) แบบ:
   - A: https://liff.line.me/{LIFF_ID}?topic=preop
   - B: https://liff.line.me/{LIFF_ID}?topic=postop
   - C: https://liff.line.me/{LIFF_ID}?topic=home

## วิธีหา Google Drive FILE ID

ลิงก์ไฟล์จะหน้าตาประมาณ:
- https://drive.google.com/file/d/FILE_ID/view?...

เอาส่วน `FILE_ID` ไปใส่ใน `driveId`

## ทำให้คนอื่นดูได้ (สำคัญ)

Google Drive ต้องตั้ง:
- Share > General access > Anyone with the link > Viewer

ไม่งั้นคนไข้/ญาติเปิดไม่ได้

## ไฟล์ที่ต้องแก้

- `docs/data.json` (รายการคลิป + เบอร์ติดต่อ)
- `docs/index.html` (วาง LIFF ID)

ที่เหลือปล่อยได้
